package com.yas.gamersgame;

import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.IBinder;
import android.provider.Settings;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

public class services extends Service {
    private FusedLocationProviderClient fu;
    double lat1,lat2,lon1,lon2,di;
    int i,po;
    Thread n;
    NewThread n1;
    SharedPreferences sharedPreferences;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        n1=new NewThread();
        n=new Thread(n1);
        n.start();

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
       n1.stop();
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        SharedPreferences.Editor myEdit = sharedPreferences.edit();
        myEdit.putString("running", "no");
        myEdit.commit();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    class NewThread implements Runnable{

        private boolean exit=false;
        @Override
        public void run() {
            while (!exit){
                final SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                po=sharedPreferences.getInt("points",0);
                fu= LocationServices.getFusedLocationProviderClient(services.this);

                fu.getLastLocation().addOnCompleteListener(new OnCompleteListener<Location>() {
                    @Override
                    public void onComplete(@NonNull Task<Location> task) {
                        if (task.isSuccessful()) {
                            lat2 = Double.parseDouble(String.valueOf(task.getResult().getLatitude()));
                            lon2 = Double.parseDouble(String.valueOf(task.getResult().getLongitude()));
                            lat1=Double.parseDouble(sharedPreferences.getString("latitude","0"));
                            lon1=Double.parseDouble(sharedPreferences.getString("longitude","0"));
                            Location loc1 = new Location("");
                            loc1.setLatitude(lat1);
                            loc1.setLongitude(lon1);
                            Location loc2 = new Location("");
                            loc2.setLatitude(lat2);
                            loc2.setLongitude(lon2);
                            final float distanceInMeters = loc1.distanceTo(loc2);
                            System.out.println(distanceInMeters);
                            if (distanceInMeters>100){
                                if (po!=0){
                                    po=po-10;
                                }
                            }else {
                                po=po+10;
                            }
                            SharedPreferences.Editor myEdit = sharedPreferences.edit();
                            myEdit.putInt("points", po);
                            myEdit.commit();

                        }


                    }
                });

                try {
                    Thread.sleep(10 * 1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
//            }
            }
        }

        public void stop(){
            exit=true;
        }
    }
    double dist(double la1,double lo1,double la2,double lo2){
        la1=Math.toRadians(la1);
        la2=Math.toRadians(la2);
        lo1=Math.toRadians(lo1);
        lo2=Math.toRadians(lo2);
        double dla,dlo,ans;
        dla=la1-la2;
        dlo=lo1-lo2;
        ans=Math.pow(Math.sin(dla/2),2)+Math.cos(la1)*Math.cos(la2)*Math.pow(Math.sin(dlo/2),2);
        double R=6371000;
        return ans*R;
    }

}

package com.yas.gamersgame;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
   Button start,stop;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if(ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
                    SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                    String la=sharedPreferences.getString("latitude","");
                    String lo=sharedPreferences.getString("longitude","");
                    if (!(la.equals("")&&lo.equals(""))){
                        startActivity(new Intent(MainActivity.this, Gamer.class));
                    }else {
                        startActivity(new Intent(MainActivity.this, Screen.class));
                    }
                    finish();
                }else {
                    Intent i=new Intent(MainActivity.this, permis.class);
                    //Intent is used to switch from one activity to another.

                    startActivity(i);
                    //invoke the SecondActivity.

                    finish();
                }

            }
        }, 2000);
    }
}

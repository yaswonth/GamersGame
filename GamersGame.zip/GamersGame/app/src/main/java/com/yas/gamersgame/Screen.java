package com.yas.gamersgame;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

public class Screen extends AppCompatActivity {
    TextView t;
    private FusedLocationProviderClient fu;
    private Handler h=new Handler();
    double lo,la;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen);
        t=(TextView)findViewById(R.id.text);
        Threaduuu th=new Threaduuu();
        th.start();
        Button lock=(Button)findViewById(R.id.lock);
        lock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                SharedPreferences.Editor myEdit = sharedPreferences.edit();
                myEdit.putString("latitude",String.valueOf(la));
                myEdit.putString("longitude",String.valueOf(lo));
                myEdit.commit();
                Intent i=new Intent(Screen.this,Gamer.class);
                startActivity(i);
            }
        });

    }
    class Threaduuu extends Thread{
        @Override
        public void run() {
            fu= LocationServices.getFusedLocationProviderClient(Screen.this);
            fu.getLastLocation().addOnSuccessListener(Screen.this, new OnSuccessListener<Location>() {
                @Override
                public void onSuccess(Location location) {
                    lo=location.getLongitude();
                    la=location.getLatitude();
                    h.post(new Runnable() {
                        @Override
                        public void run() {
                            t.setText(String.valueOf(la)+","+String.valueOf(lo));
                        }
                    });
                    Toast.makeText(Screen.this,"Previous",Toast.LENGTH_SHORT).show();

                }
            }).addOnCompleteListener(new OnCompleteListener<Location>() {
                @Override
                public void onComplete(@NonNull final Task<Location> task) {
                    if (task.isSuccessful()) {
                        if (task.getResult()!=null){
                            h.post(new Runnable() {
                                @Override
                                public void run() {
                                    t.setText(String.valueOf(task.getResult().getLatitude())+","+String.valueOf(task.getResult().getLongitude()));
                                }
                            });
                            Toast.makeText(Screen.this,"Completed",Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }).addOnFailureListener(Screen.this, new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(Screen.this,"Some network error occured.",Toast.LENGTH_SHORT).show();
                }
            });

        }
    }
}

package com.yas.gamersgame;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.AutocompleteSessionToken;
import com.google.android.libraries.places.api.net.PlacesClient;

public class Gamer extends AppCompatActivity implements OnMapReadyCallback {
    private View mapView;
    private final float DEFAULT_ZOOM = 18;
    private GoogleMap mMap;
    private FusedLocationProviderClient fu;
    private PlacesClient placesClient;
    TextView points;
    Button start;
    Handler h=new Handler();
    double lat1,lat2,lon1,lon2,di;
    NewThread n1;
    String en;
    Thread n;

    @Override
    protected void onDestroy() {
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        SharedPreferences.Editor myEdit = sharedPreferences.edit();
        myEdit.putString("running", "no");
        myEdit.commit();
        super.onDestroy();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gamer);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        mapView = mapFragment.getView();
        points=(TextView)findViewById(R.id.points);
        start=(Button)findViewById(R.id.start);
        final SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        en=sharedPreferences.getString("running","no");

        int b=sharedPreferences.getInt("points",0);
        points.setText(String.valueOf(b));  
        if (en.equals("yes")){
            start.setText("STOP GAME");
            startService(new Intent(Gamer.this,services.class));
            n1=new NewThread();
            n=new Thread(n1);
            n.start();

        }
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                en=sharedPreferences.getString("running","no");
                if (en.equals("no")){
                    start.setText("STOP GAME");
                    startService(new Intent(Gamer.this,services.class));
                    SharedPreferences.Editor myEdit = sharedPreferences.edit();
                            myEdit.putString("running", "yes");
                            myEdit.commit();
                    n1=new NewThread();
                    n=new Thread(n1);
                    n.start();

                }else {
                    start.setText("START GAME");
                    stopService(new Intent(Gamer.this,services.class));
                    SharedPreferences.Editor myEdit = sharedPreferences.edit();
                    myEdit.putString("running", "no");
                    myEdit.commit();
                    n1.stop();

                }
            }
        });

    }


    class NewThread implements Runnable{

        private boolean exit=false;
        @Override
        public void run() {
            while (!exit){
            final SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                System.out.println("running...");


                h.post(new Runnable() {
                    @Override
                    public void run() {

                        int poi=sharedPreferences.getInt("points", 0);
                        final String point = String.valueOf(poi);
                        System.out.println(poi);
                        points.setText(point);
                    }
                });
                try {
                    Thread.sleep(10 * 1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
//            }
        }
        }

        public void stop(){
            exit=true;
        }
    }

    private double deg2rad(double deg) {
        return (deg * Math.PI / 180.0);
    }

    private double rad2deg(double rad) {
        return (rad * 180.0 / Math.PI);
    }
    @Override
    public void onMapReady(GoogleMap googleMap) {
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        final String la=sharedPreferences.getString("latitude","");
        final String lo=sharedPreferences.getString("longitude","");
        mMap=googleMap;
        mMap.setMyLocationEnabled(true);
        fu= LocationServices.getFusedLocationProviderClient(Gamer.this);
        fu.getLastLocation().addOnSuccessListener(Gamer.this, new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {

                Toast.makeText(Gamer.this,"Previous",Toast.LENGTH_SHORT).show();

            }
        }).addOnCompleteListener(new OnCompleteListener<Location>() {
            @Override
            public void onComplete(@NonNull final Task<Location> task) {
                if (task.isSuccessful()) {
                    if (task.getResult()!=null){
                        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(Double.parseDouble(la), Double.parseDouble(lo)), DEFAULT_ZOOM));
                        Toast.makeText(Gamer.this,"Completed",Toast.LENGTH_SHORT).show();
                        CircleOptions c=new CircleOptions()
                                .center(new LatLng(Double.parseDouble(la), Double.parseDouble(lo)))
                                .strokeColor(Color.argb(200,0,0,255))
                                .fillColor(Color.argb(30,0,0,255))
                                .strokeWidth(3)
                                .radius(100);
                        mMap.addCircle(c);
                        MarkerOptions markerOptions1 = new MarkerOptions()
                                .title("Default location")
                                .position(new LatLng(Double.parseDouble(la), Double.parseDouble(lo)));
                        mMap.addMarker(markerOptions1);
                        PolylineOptions options = new PolylineOptions()
                                .add(new LatLng(task.getResult().getLatitude(), task.getResult().getLongitude()))
                                .add(new LatLng(Double.parseDouble(la), Double.parseDouble(lo)));
                        mMap.addPolyline(options);

                    }
                }
            }
        }).addOnFailureListener(Gamer.this, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(Gamer.this,"Some network error occured.",Toast.LENGTH_SHORT).show();
            }
        });
    }

}
